# -*- coding: utf-8 -*-

from lx_bloomfilter.py_bloomfilter import BloomFilter